<?php

class Kirki_Sanitize extends Kirki_Customizer {}
